cal = {1:{"file":"gt.csv", "shift":0.0},
	   2:{"file":"downsampling.csv", "shift":-0.305}, 
	   3:{"file":"cs_result.csv", "shift":-0.585}, 
	   4:{"file":"baseline_128_result.csv", "shift":-0.89}, 
	   5:{"file":"baseline_16_result.csv", "shift":-1.050},
	   6:{"file":"lossless_result.csv", "shift":-1.415}}

start = 400
stop = 1300

# PRR
# 1	 100.00
# 2	 80.38
# 3	 97.90
# 4	 33.03
# 5	 25.12

# Distortion
# 2	 0.068
# 3	 0.042
# 4	 0.102
# 5	 0.062
# 6	 0.114
