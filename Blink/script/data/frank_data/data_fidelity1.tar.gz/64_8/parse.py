import sys
import math

import mytool as mt

node = {}
node[1] = "gt.dat"
for i in range(2, 7):
	node[i] = "all.dat"

for ID in node:
	print "NodeID=%d, file=%s"%(ID, node[ID])

	openfile = open(node[ID], "r")
	outputfile = open("%d.dat"%ID, "w")

	cookie = -1
	align = False

	for line in openfile:
		try:
			tmp = line.rstrip().rsplit(",")

			if int(tmp[0]) == ID:
				_cookie = int(tmp[4])
				seqno = int(tmp[5])

				if seqno == 0:
					align = True

				if not align or _cookie == cookie:
					continue

				else:
					outputfile.write(line)
					cookie = _cookie

		except:
			pass

	openfile.close()
	outputfile.close()
