node = {3:64, 4:4}

for ID in node:
	print "NodeID=%d"%ID
	openfile = open("%d.dat"%ID, "r")
	outputfile = open("%d_.dat"%ID, "w")
	prev_pkt = -1
	prev_line = ""

	for line in openfile:
		tmp = line.rstrip().rsplit(",")

		curr_pkt = int(tmp[5])

		if curr_pkt == 0 and prev_pkt != -1:
			tmp = prev_line.rstrip().rsplit(",")
			for j in range(prev_pkt+1, node[ID]):
				mystr = "%s,%d,%s,%s\n"%(",".join(tmp[0:5]), j, 
										 ",".join(tmp[6:9]), ",".join(["-1"] * 16))
				outputfile.write(mystr)

		outputfile.write(line)

		prev_pkt = curr_pkt
		prev_line = line

	openfile.close()
	outputfile.close()
