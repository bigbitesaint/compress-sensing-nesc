cp 1.dat ~/Dropbox/compressive/Blink/script/plot/
cp 2.dat ~/Dropbox/compressive/Blink/script/plot/
cp 3_.dat ~/Dropbox/compressive/Blink/script/compressive/
cp 4_.dat ~/Dropbox/compressive/Blink/script/baseline_128/
cp 5.dat ~/Dropbox/compressive/Blink/script/baseline_16/
cp 6.dat ~/Dropbox/compressive/Blink/script/lossless/
