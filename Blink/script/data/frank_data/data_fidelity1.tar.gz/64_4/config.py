CAL = {1:{"file":"gt.csv", "shift":0.0},
	   2:{"file":"downsampling.csv", "shift":-0.66}, 
	   3:{"file":"cs_result.csv", "shift":-2.84}, 
	   4:{"file":"baseline_128_result.csv", "shift":-4.055}, 
	   5:{"file":"baseline_16_result.csv", "shift":-1.04},
	   6:{"file":"lossless_result.csv", "shift":-1.845}}

START = 71500
STOP = 72400

# PRR
# 1	 100.00
# 2	 77.11
# 3	 82.38
# 4	 17.41
# 5	 18.89

# Distortion
# 2	 0.077
# 3	 0.034
# 4	 0.081
# 5	 0.077
# 6	 0.108
