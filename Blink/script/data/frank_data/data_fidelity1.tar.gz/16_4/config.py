CAL = {1:{"file":"gt.csv", "shift":0.0},
	   2:{"file":"downsampling.csv", "shift":-0.321}, 
	   3:{"file":"cs_result.csv", "shift":-0.567}, 
	   4:{"file":"baseline_128_result.csv", "shift":-0.825}, 
	   5:{"file":"baseline_16_result.csv", "shift":-1.272},
	   6:{"file":"lossless_result.csv", "shift":-1.146}}

START = 1000
STOP = 1900

# PRR
# 1	100.00
# 2	99.71
# 3	100.00
# 4	98.91
# 5	75.06

# Distortion
# 2	 0.029
# 3	 0.019
# 4	 0.018
# 5	 0.058
# 6	 0.137
