node = {}
node[1] = [2, 256*4]
node[2] = [2, 1024*4]
node[3] = [64, 32768*4]
node[4] = [4, 2048*4]
node[5] = [1, 256*4]

for ID in node:
	try:
		openfile = open("%d.dat"%ID, "r")
		lines = openfile.readlines()
		actual = len(lines)
		openfile.close()
		tmp = lines[0].rstrip().rsplit(",")
		start = int(tmp[1])

		tmp = lines[-1].rstrip().rsplit(",")
		stop = int(tmp[2])

		elap = stop - start
		expect = 1.0 * node[ID][0] * elap / node[ID][1]
		prr = 100.0 * actual / expect
		print "%d\t%.2f"%(ID, prr)
	except:
		print "Error processing node %d"%ID
		pass
	
