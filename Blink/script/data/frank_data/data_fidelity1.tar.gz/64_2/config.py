cal = {1:{"file":"gt.csv", "shift":0.0},
	   2:{"file":"downsampling.csv", "shift":-0.285}, 
	   3:{"file":"cs_result.csv", "shift":-0.555}, 
	   4:{"file":"baseline_128_result.csv", "shift":-0.885}, 
	   5:{"file":"baseline_16_result.csv", "shift":-1.000},
	   6:{"file":"lossless_result.csv", "shift":-1.415}}

start = 400
stop = 1300

# PRR
# 1	 100.01
# 2	 77.65
# 3	 37.77
# 4	 7.28
# 5	 21.07

# Distortion
# 2	 0.092
# 3	 0.038
# 4	 0.180
# 5	 0.078
# 6	 0.107
