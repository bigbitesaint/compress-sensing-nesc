import matplotlib.pyplot as plt

seqno = []
openfile = open("../64_2/4.dat", "r")
for line in openfile:
	tmp = line.rstrip().rsplit(",")
	seqno.append(int(tmp[5]))
openfile.close()

plt.plot(seqno, "-x")
plt.show()
