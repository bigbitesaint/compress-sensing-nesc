cal = {1:{"file":"gt.csv", "shift":0.0},
	   2:{"file":"downsampling.csv", "shift":-0.288}, 
	   3:{"file":"cs_result.csv", "shift":-0.570}, 
	   4:{"file":"baseline_128_result.csv", "shift":-0.891}, 
	   5:{"file":"baseline_16_result.csv", "shift":-1.143},
	   6:{"file":"lossless_result.csv", "shift":-1.401}}

start = 200
stop = 1100

# PRR
# 1	 100.00
# 2	 94.04
# 3	 95.66
# 4	 76.71
# 5	 54.72

# Distortion
# 2	 0.034
# 3	 0.021
# 4	 0.042
# 5	 0.068
# 6	 0.027
