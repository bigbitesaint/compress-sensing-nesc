for (( i=0; i<=4; i++ ))
do
    make telosb reinstall,$(($i+10)) bsl,/dev/ttyUSB$i
done